#!/bin/bash
#SBATCH --job-name=PartitionFinder
#SBATCH --chdir=.
#SBATCH --output=job_partitionfinder_%j.out
#SBATCH --error=job_partitionfinder_%j.err
#SBATCH --ntasks=2
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --time=1-00:00:00


## Load modules
module load PARTITIONFINDER/2.1.1
module load RAxML/8.1.16


## Run PartitionFinder
./PartitionFinderMorphology.py AICc-Branches_linked/   --raxml --quick
./PartitionFinderMorphology.py AICc-Branches_unlinked/ --raxml --quick
./PartitionFinderMorphology.py BIC-Branches_linked/    --raxml --quick
./PartitionFinderMorphology.py BIC-Branches_unlinked/  --raxml --quick

# $data -> folder where you can find the .phy and .cfg files. 
# --raxml -> RAxML is necessary to analyse morphological data
# --quick -> do not save all the schemes, You will not use them anyway. With the csv summary is enough
# The .cfg file must be named "partition_finder.cfg"
