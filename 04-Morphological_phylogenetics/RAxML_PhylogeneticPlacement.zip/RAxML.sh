#!/bin/bash -l
 
#SBATCH -A snic2022-22-758
#SBATCH -p core
#SBATCH -n 2
#SBATCH -t 1-00:00:00
#SBATCH -J RAxML
#SBATCH -o job_raxml_%j.out
#SBATCH -e job_raxml_%j.err


## Load modules
module load bioinfo-tools


## Data


## Run RAxML
raxmlHPC -f u -m ASC_MULTIGAMMA --asc-corr=lewis -t Reference_tree.tre -s Characters.phy -n test -# 1000 -p 12345



raxmlHPC -f v -m ASC_MULTIGAMMA --asc-corr=lewis -t Reference_tree.tre -s All_species.phy -a RAxML_weights.test -n Morphological_placement -# 1000 -p 12345
